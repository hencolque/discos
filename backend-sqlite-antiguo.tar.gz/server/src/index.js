import express from 'express';
import multer from 'multer';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import db, { FORMATS } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });

// En producción se sirve el frontend construido (client/dist) desde este mismo servidor
const clientDist = path.join(__dirname, '..', '..', 'client', 'dist');

const app = express();
app.use(express.json());

const ALLOWED_MIME = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) =>
      cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase()),
  }),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (_req, file, cb) =>
    cb(
      ALLOWED_MIME.includes(file.mimetype)
        ? null
        : new Error('Formato de imagen no permitido (usa JPG, PNG, WebP, GIF o AVIF)'),
      ALLOWED_MIME.includes(file.mimetype),
    ),
});

function removePhoto(photoUrl) {
  if (!photoUrl || !photoUrl.startsWith('/uploads/')) return;
  fs.unlink(path.join(uploadsDir, path.basename(photoUrl)), () => {});
}

function validateItem(body) {
  const title = String(body.title ?? '').trim();
  const artist = String(body.artist ?? '').trim();
  const notes = String(body.notes ?? '').trim();
  const format = body.format;
  const price = Number(body.price);
  const condition =
    body.condition === undefined || body.condition === null || body.condition === ''
      ? 8
      : Number(body.condition);

  if (!title) return { error: 'El título es obligatorio' };
  if (!FORMATS.includes(format)) return { error: 'Formato no válido' };
  if (!Number.isFinite(price) || price < 0) return { error: 'El precio debe ser un número ≥ 0' };
  if (!Number.isInteger(condition) || condition < 1 || condition > 10)
    return { error: 'El estado debe ser un entero entre 1 y 10' };

  return { data: { title, artist, notes, format, price, condition } };
}

app.get('/api/items', (req, res) => {
  const { q, format } = req.query;
  const where = [];
  const params = [];

  if (q) {
    where.push('(title LIKE ? OR artist LIKE ? OR notes LIKE ?)');
    params.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }
  if (format && FORMATS.includes(format)) {
    where.push('format = ?');
    params.push(format);
  }

  const sql = `SELECT * FROM items ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC`;
  res.json(db.prepare(sql).all(...params));
});

app.get('/api/items/:id', (req, res) => {
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Ítem no encontrado' });
  res.json(item);
});

app.post('/api/items', upload.single('photo'), (req, res) => {
  const { error, data } = validateItem(req.body);
  if (error) {
    if (req.file) removePhoto('/uploads/' + req.file.filename);
    return res.status(400).json({ error });
  }
  const photo = req.file ? '/uploads/' + req.file.filename : null;
  const { changes, lastInsertRowid } = db
    .prepare(
      'INSERT INTO items (title, artist, format, price, notes, photo, condition) VALUES (?, ?, ?, ?, ?, ?, ?)',
    )
    .run(data.title, data.artist, data.format, data.price, data.notes, photo, data.condition);
  res.status(201).json(db.prepare('SELECT * FROM items WHERE id = ?').get(lastInsertRowid ?? changes));
});

app.put('/api/items/:id', upload.single('photo'), (req, res) => {
  const existing = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!existing) {
    if (req.file) removePhoto('/uploads/' + req.file.filename);
    return res.status(404).json({ error: 'Ítem no encontrado' });
  }

  const { error, data } = validateItem(req.body);
  if (error) {
    if (req.file) removePhoto('/uploads/' + req.file.filename);
    return res.status(400).json({ error });
  }

  let photo = existing.photo;
  if (req.file) {
    removePhoto(existing.photo);
    photo = '/uploads/' + req.file.filename;
  }

  db.prepare(
    'UPDATE items SET title = ?, artist = ?, format = ?, price = ?, notes = ?, photo = ?, condition = ? WHERE id = ?',
  )
    .run(data.title, data.artist, data.format, data.price, data.notes, photo, data.condition, req.params.id);
  res.json(db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id));
});

app.delete('/api/items/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Ítem no encontrado' });
  removePhoto(existing.photo);
  db.prepare('DELETE FROM items WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

app.use('/uploads', express.static(uploadsDir, { maxAge: '30d' }));

if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  // Fallback SPA: cualquier ruta que no sea API/uploads devuelve index.html
  app.use((req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/api') || req.path.startsWith('/uploads')) return next();
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

// Errores de Multer (archivo muy grande, mime inválido) como JSON legible
app.use((err, _req, res, _next) => {
  const message =
    err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE'
      ? 'La imagen supera el límite de 5 MB'
      : err.message || 'Error interno';
  res.status(400).json({ error: message });
});

const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`✅ Discoteca API lista en http://localhost:${port}`));
