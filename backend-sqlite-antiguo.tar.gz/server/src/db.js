import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, '..', 'data');
mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, 'discos.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS items (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT    NOT NULL,
    artist     TEXT    NOT NULL DEFAULT '',
    format     TEXT    NOT NULL,
    price      REAL    NOT NULL DEFAULT 0,
    notes      TEXT    NOT NULL DEFAULT '',
    photo      TEXT,
    condition  INTEGER NOT NULL DEFAULT 8,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  );
`);

// Migración ligera para BDs creadas antes del campo condition (falla si ya existe)
try {
  db.exec('ALTER TABLE items ADD COLUMN condition INTEGER NOT NULL DEFAULT 8');
} catch {
  // columna ya presente, nada que migrar
}

export const FORMATS = ['CD', 'Vinilo', 'Cassette', 'VHS', 'DVD', 'Blu-ray', 'MiniDisc', 'Otro'];

export default db;
